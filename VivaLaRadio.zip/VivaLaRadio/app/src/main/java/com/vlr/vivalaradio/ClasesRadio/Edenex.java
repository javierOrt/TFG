package com.vlr.vivalaradio.ClasesRadio;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;
import android.media.MediaPlayer.OnBufferingUpdateListener;
import android.media.MediaPlayer.OnPreparedListener;

import com.vlr.vivalaradio.MainActivity;
import com.vlr.vivalaradio.R;
import com.vlr.vivalaradio.PanelRadioActivity;

import java.io.IOException;

public class Edenex extends AppCompatActivity implements View.OnClickListener {

    Button btnPlayEdenex, btnStopEdenex, btnVolverEdenex, btnWebEdenex;
    MediaPlayer mediaplayerEdenex;
    ProgressBar progressBarEdenex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edenex);
        WebView webView = this.findViewById(R.id.webViewEdenex);
        webView.loadUrl("https://www.edenex.es/wp-content/uploads/2017/07/cropped-edenexlogo.png");

        inicializarComponentes2();
        initializarMediaPlayer2();

    }
    private void inicializarComponentes2() {
        btnPlayEdenex = findViewById(R.id.btn_playedenex);
        btnStopEdenex = findViewById(R.id.btn_stopedenex);
        btnVolverEdenex = findViewById(R.id.btn_volveredenex);
        btnWebEdenex = findViewById(R.id.btn_WebEdenex);
        progressBarEdenex = findViewById(R.id.progressBarEdenex);
        progressBarEdenex.setMax(100);
        progressBarEdenex.setVisibility(View.INVISIBLE);

        btnPlayEdenex.setOnClickListener(this);
    }
    //Botonera
    @Override
    public void onClick(View v) {
        if (btnPlayEdenex.isClickable()) {
            btnStopEdenex.setEnabled(true);
            btnPlayEdenex.setEnabled(false);
            progressBarEdenex.setVisibility(View.VISIBLE);
            mediaplayerEdenex.prepareAsync();
            mediaplayerEdenex.setOnPreparedListener(new OnPreparedListener() {

                public void onPrepared(MediaPlayer mp1) {
                    mediaplayerEdenex.start();
                }
            });
        }
    }
    public void stop (View v){
        if (btnStopEdenex.isClickable()){
            btnStopEdenex.setEnabled(false);
            btnPlayEdenex.setEnabled(true);
            progressBarEdenex.setVisibility(View.INVISIBLE);
            detener();
        }
    }

    private void detener() {
        if (mediaplayerEdenex.isPlaying())
        {
            mediaplayerEdenex.stop();
        }
    }

    public void regreso (View v){
        if (btnVolverEdenex.isClickable()){
            Intent ir = new Intent(this, PanelRadioActivity.class);
            startActivity(ir);
            detener();
        }
    }

    public void irWebEdenex(View v){
        if (v.getId() == R.id.btn_WebEdenex) {
            Uri Webpage = Uri.parse("https://www.edenex.es");
            Intent intent = new Intent(Intent.ACTION_VIEW, Webpage);
            if (intent.resolveActivity(getPackageManager()) != null) {
                startActivity(intent);
            }
        }
    }
    //Mediaplayer
    private void initializarMediaPlayer2() {
        mediaplayerEdenex = new MediaPlayer();
        try {
            mediaplayerEdenex.setDataSource("https://cervera.eldialdigital.com:23121/stream"); //EDENEX Radio
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (IllegalStateException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        mediaplayerEdenex.setOnBufferingUpdateListener(new OnBufferingUpdateListener() {
            public void onBufferingUpdate(MediaPlayer mp1, int percent) {
                progressBarEdenex.setSecondaryProgress(percent);
                Log.i("Buffering", "" + percent);
            }
        });
    }


    //AREA PARA EL MENU ACTION BAR
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_superior,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id=item.getItemId();
        if (id==R.id.item_salir){
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
        if (id==R.id.item_creator){
            Toast.makeText(this, "Aplicacion creada por:Javier Ortiz; David romeral ;2022",Toast.LENGTH_LONG).show();
            return true;
        }
        if (id==R.id.i_version){
            Toast.makeText(this, "Version de la aplicacion: 1.0",Toast.LENGTH_LONG).show();
            return true;
        }

        return  super.onOptionsItemSelected(item);
    }
}
