package com.vlr.vivalaradio.ClasesRadio;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.vlr.vivalaradio.MainActivity;
import com.vlr.vivalaradio.R;
import com.vlr.vivalaradio.PanelRadioActivity;

import java.io.IOException;

public class CadenaSer extends AppCompatActivity implements View.OnClickListener {
    Button btnPlayCadenaSer, btnStopCadenaSer, btnVolverCadenaSer, btnWebCadenaSer;
    MediaPlayer mediaCadenaSer;
    ProgressBar progressBarCadenaSer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadenaser);

        WebView webView = this.findViewById(R.id.webViewCadenaSer);
        webView.loadUrl("https://www.radio.es/images/broadcasts/96/0a/33036/c300.png"); //carga una imagen remota

        inicializarComponentesCadenaSer(); //inicializalos componentes de la pagina
        inicializarMPlayerCadenaSer();
    }

    private void inicializarComponentesCadenaSer() {
        btnPlayCadenaSer = findViewById(R.id.btn_playcadenaser);
        btnStopCadenaSer = findViewById(R.id.btn_stopcadenaser);
        btnVolverCadenaSer = findViewById(R.id.btn_volvercadenaser);
        btnWebCadenaSer = findViewById(R.id.btn_webcadenaser);
        progressBarCadenaSer = findViewById(R.id.progressBarcadenaser);
        progressBarCadenaSer.setMax(100);
        progressBarCadenaSer.setVisibility(View.INVISIBLE);
        btnPlayCadenaSer.setOnClickListener(this);
    }
    //tabla de botones
    @Override
    public void onClick(View v) {
        if (btnPlayCadenaSer.isClickable()) {
            btnStopCadenaSer.setEnabled(true);
            btnPlayCadenaSer.setEnabled(false);
            progressBarCadenaSer.setVisibility(View.VISIBLE);
            mediaCadenaSer.prepareAsync();
            mediaCadenaSer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {

                public void onPrepared(MediaPlayer mp1) {
                    mediaCadenaSer.start();
                }
            });
        }
    }
    public void stop (View v){
        if (btnStopCadenaSer.isClickable()){
            btnStopCadenaSer.setEnabled(false);
            btnPlayCadenaSer.setEnabled(true);
            progressBarCadenaSer.setVisibility(View.INVISIBLE);
            detener();
        }
    }

    private void detener() {
        if (mediaCadenaSer.isPlaying())
        {
            mediaCadenaSer.stop();
        }
    }

    public void regresar (View v){
        if (btnVolverCadenaSer.isClickable()){
            Intent ir = new Intent(this, PanelRadioActivity.class);
            startActivity(ir);
            detener();
        }
    }
    public void irWebCadenaSer(View v){
        if (v.getId() == R.id.btn_webcadenaser) {
            Uri Webpage = Uri.parse("https://cadenaser.com/");
            Intent intent = new Intent(Intent.ACTION_VIEW, Webpage);
            if (intent.resolveActivity(getPackageManager()) != null) {
                startActivity(intent);
            }
        }
    }

    private void inicializarMPlayerCadenaSer() {
        mediaCadenaSer = new MediaPlayer();
        try {
            mediaCadenaSer.setDataSource("https://20043.live.streamtheworld.com/SER_MAS_MADRID.mp3"); //cadena ser
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (IllegalStateException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        mediaCadenaSer.setOnBufferingUpdateListener(new MediaPlayer.OnBufferingUpdateListener() {
            public void onBufferingUpdate(MediaPlayer mp1, int percent) {
                progressBarCadenaSer.setSecondaryProgress(percent);
                Log.i("Buffering", "" + percent);
            }
        });
    }

    //AREA PARA EL MENU ACTION BAR
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_superior,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id=item.getItemId();
        if (id==R.id.item_salir){
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
        if (id==R.id.item_creator){
            Toast.makeText(this, "Aplicacion creada por:Javier Ortiz; David romeral ;2022",Toast.LENGTH_LONG).show();
            return true;
        }
        if (id==R.id.i_version){
            Toast.makeText(this, "Version de la aplicacion: 1.0",Toast.LENGTH_LONG).show();
            return true;
        }

        return  super.onOptionsItemSelected(item);
    }
}
