package com.vlr.vivalaradio.ClasesRadio;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.vlr.vivalaradio.MainActivity;
import com.vlr.vivalaradio.R;
import com.vlr.vivalaradio.PanelRadioActivity;

import java.io.IOException;

public class VivaRadio extends AppCompatActivity implements View.OnClickListener {
    Button btnPlayVivaRadio, btnStopVivaRadio, btnVolverVivaRadio, btnWebVivaRadio;
    MediaPlayer mediaplayerVivaRadio;
    ProgressBar progressBarVivaRadio;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vivaradio);
        WebView webView = this.findViewById(R.id.webViewVivaRadio);
        webView.loadUrl("https://cdn-profiles.tunein.com/s299199/images/logod.jpg?t=162257");

        inicializarComponentes();
        inicializarMediaPlayer();
    }
    //inicializacion de componentes
    private void inicializarComponentes() {
        btnPlayVivaRadio = findViewById(R.id.btnPlayVivaRadio);
        btnStopVivaRadio = findViewById(R.id.btnStopVivaRadio);
        btnVolverVivaRadio = findViewById(R.id.btnVolverVivaRadio);
        btnWebVivaRadio =findViewById(R.id.btnWebVivaRadio);
        progressBarVivaRadio = findViewById(R.id.progressBarVivaRadio);
        progressBarVivaRadio.setMax(100);
        progressBarVivaRadio.setVisibility(View.INVISIBLE);
        btnPlayVivaRadio.setOnClickListener(this);
    }
    //BOTONERA
    @Override
    public void onClick(View v) {
        if (btnPlayVivaRadio.isClickable()) {
            btnStopVivaRadio.setEnabled(true);
            btnPlayVivaRadio.setEnabled(false);
            progressBarVivaRadio.setVisibility(View.VISIBLE);
            mediaplayerVivaRadio.prepareAsync();
            mediaplayerVivaRadio.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {

                public void onPrepared(MediaPlayer mp1) {
                    mediaplayerVivaRadio.start();
                }
            }); //este boton activa el reproductor de radio
        }
    }
    public void stop (View v){
        btnStopVivaRadio.setEnabled(false);
        btnPlayVivaRadio.setEnabled(true);
        progressBarVivaRadio.setVisibility(View.INVISIBLE);
        detener(); //boton de detencion
    }

    private void detener() { //metodo compartido de stop playing
        if (btnStopVivaRadio.isClickable()){
            if (mediaplayerVivaRadio.isPlaying())
            {
                mediaplayerVivaRadio.stop();
            }
        }
    }

    public void regreso (View v){ //retrocede
        if (btnVolverVivaRadio.isClickable()){
            Intent ir = new Intent(this, PanelRadioActivity.class);
            startActivity(ir);
            detener();
        }
    }
    public void ir_webVivaRadio(View v){
        if (v.getId() == R.id.btnWebVivaRadio) {
            Uri Webpage = Uri.parse("https://vivaradio.es");
            Intent intent = new Intent(Intent.ACTION_VIEW, Webpage);
            if (intent.resolveActivity(getPackageManager()) != null) {
                startActivity(intent);
            }
        }
    }

    //inicializa el media player con este metodo
    private void inicializarMediaPlayer() {
        mediaplayerVivaRadio = new MediaPlayer();
        try {
            mediaplayerVivaRadio.setDataSource("https://eu1.lhdserver.es:3019/stream"); //VIVA radio
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (IllegalStateException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    //inicia el buffering
        mediaplayerVivaRadio.setOnBufferingUpdateListener(new MediaPlayer.OnBufferingUpdateListener() {
            public void onBufferingUpdate(MediaPlayer mp1, int percent) {
                progressBarVivaRadio.setSecondaryProgress(percent);
                Log.i("Buffering", "" + percent);
            }
        });
    }


    //AREA PARA EL MENU ACTION BAR
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_superior,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id=item.getItemId();
        if (id==R.id.item_salir){
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
        if (id==R.id.item_creator){
            Toast.makeText(this, "Aplicacion creada por:Javier Ortiz; David romeral ;2022",Toast.LENGTH_LONG).show();
            return true;
        }
        if (id==R.id.i_version){
            Toast.makeText(this, "Version de la aplicacion: 1.0",Toast.LENGTH_LONG).show();
            return true;
        }

        return  super.onOptionsItemSelected(item);
    }

}
