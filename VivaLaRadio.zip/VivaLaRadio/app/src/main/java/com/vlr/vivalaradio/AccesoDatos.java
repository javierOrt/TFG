package com.vlr.vivalaradio;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class AccesoDatos extends AppCompatActivity {
    EditText ed_introducirNombre;
    Button bt_buscar,bt_regresar;
    TextView id_emisora,tvnombre,tvciudad,tvstream;
    RequestQueue requestQueue;
    String datosConsulta="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_acceso_datos);
        ed_introducirNombre = findViewById(R.id.editTextbuscar_emisora);
        id_emisora = findViewById(R.id.textViewIDemisora);
        tvnombre = findViewById(R.id.textViewNOmbreEmisora);
        tvciudad = findViewById(R.id.textViewCiudadE);
        tvstream = findViewById(R.id.textViewDirStream);
        bt_buscar  = findViewById(R.id.buttonBuscar);
        bt_regresar = findViewById(R.id.buttonretro);

        bt_buscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String IP_servidor ="http://192.168.1.133:8080/DBradio/buscar_emiosras.php?ID_emisora=" +ed_introducirNombre.getText()+"";
                buscarEmisora(IP_servidor);
            }
        });
    }
    public void volver_comentarios(View v){
        if (bt_regresar.isClickable()){
            Intent intent = new Intent(this, SeccionComentariosActivity.class);
            startActivity(intent);
        }
    }

    private void buscarEmisora (String IP)
    {

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(IP, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                JSONObject jsonObject = null;
                try{
                    for (int i = 0; i < response.length(); i++) {
                        try {
                            jsonObject = response.getJSONObject(i);
                            id_emisora.setText(jsonObject.getString("ID_emisora"));
                            tvnombre.setText(jsonObject.getString("nombre_emisora"));
                            tvciudad.setText(jsonObject.getString("ciudad"));
                            tvstream.setText(jsonObject.getString("stream"));

                        } catch (JSONException e) {
                            Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
        requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(jsonArrayRequest);
    }


    //AREA PARA EL MENU ACTION BAR
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_superior,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id=item.getItemId();
        if (id==R.id.item_salir){
            Intent intent = new Intent(this,MainActivity.class);
            startActivity(intent);
        }
        if (id==R.id.item_creator){
            Toast.makeText(this, "Aplicacion creada por:Javier Ortiz; David romeral ;2022",Toast.LENGTH_LONG).show();
            return true;
        }
        if (id==R.id.i_version){
            Toast.makeText(this, "Version de la aplicacion: 1.0",Toast.LENGTH_LONG).show();
            return true;
        }

        return  super.onOptionsItemSelected(item);
    }

}
