package com.vlr.vivalaradio;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.vlr.vivalaradio.ClasesInfoRadio.HistotriaRadio;
import com.vlr.vivalaradio.ClasesRadio.RN5;
import com.vlr.vivalaradio.ClasesRadio.CadenaSer;
import com.vlr.vivalaradio.ClasesRadio.Edenex;
import com.vlr.vivalaradio.ClasesRadio.VivaRadio;
import com.vlr.vivalaradio.ClasesRadio.Cadena100;
import com.vlr.vivalaradio.ClasesRadio.RockFM;

public class PanelRadioActivity extends AppCompatActivity implements AdapterView.OnItemClickListener, View.OnClickListener {
    String[] radios = {"EDENEX Radio", "Rock Fm", "Cadena 100","Cadena Ser", "RNE Radio Nacional","VIVA radio"};
    ListView lista;
    TextView tv_panel;
    Button bt_inicioMain, bt_Historia, bt_comments;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_panel_radio);
        bt_inicioMain=findViewById(R.id.buttonInicio);
        bt_Historia=findViewById(R.id.buttonHistoria);

        bt_comments = findViewById(R.id.buttonComentario);
        bt_Historia.setOnClickListener(this);
        tv_panel = findViewById(R.id.textViewPanel);
        lista=findViewById(R.id.listaRadios);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, radios);
        lista.setAdapter(adapter);
        lista.setOnItemClickListener(this);
    }
    @Override
    public void onClick(View v) {
        Intent intent = new Intent(this, HistotriaRadio.class);
        startActivity(intent);
    }
    public  void bt_comments(View v){
        Intent intent = new Intent(this, SeccionComentariosActivity.class);
        startActivity(intent);
    }
    public void inicioMain(View v){
        if(bt_inicioMain.isClickable()){
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
    }


    //Selección de radio
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Toast.makeText(this, "has elegido " + radios[position], Toast.LENGTH_LONG).show();
        if (position == 0) {
            Intent myIntent = new Intent(view.getContext(), Edenex.class);
            startActivity(myIntent);

        } else if (position == 1) {
            Intent myIntent2 = new Intent(view.getContext(), RockFM.class);
            startActivity(myIntent2);

        } else if (position == 2) {
            Intent myIntent3 = new Intent(view.getContext(), Cadena100.class);
            startActivity(myIntent3);

        } else if (position == 3) {
            Intent myIntent4 = new Intent(view.getContext(), CadenaSer.class);
            startActivity(myIntent4);

        } else if (position == 4) {
            Intent myIntent5 = new Intent(view.getContext(), RN5.class);
            startActivity(myIntent5);

        } else if (position == 5) {
            Intent myIntent6 = new Intent(view.getContext(), VivaRadio.class);
            startActivity(myIntent6);

        }
    }


    //MENU
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_superior,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id=item.getItemId();
        if (id==R.id.item_salir){
            Intent intent = new Intent(this,MainActivity.class);
            startActivity(intent);
        }
        if (id==R.id.item_creator){
            Toast.makeText(this, "Aplicacion creada por:Javier Ortiz; David romeral ;2022",Toast.LENGTH_LONG).show();
            return true;
        }
        if (id==R.id.i_version){
            Toast.makeText(this, "Version de la aplicacion: 1.0",Toast.LENGTH_LONG).show();
            return true;
        }

        return  super.onOptionsItemSelected(item);
    }
}
